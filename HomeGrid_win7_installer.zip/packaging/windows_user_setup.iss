#ifndef AppVersion
  #define AppVersion "2.25"
#endif

#ifndef OutputBaseFilename
  #define OutputBaseFilename "HomeGridBackup_Setup"
#endif

[Setup]
AppId={{849CA065-D972-41A1-BA97-1B3858B1CA4B}
AppName=HomeGrid Backup
AppVersion={#AppVersion}
AppPublisher=HomeGrid
DefaultDirName={localappdata}\Programs\HomeGridBackup
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
MinVersion=6.1
OutputDir=installer_output
OutputBaseFilename={#OutputBaseFilename}
SetupIconFile=..\icon.ico
UninstallDisplayIcon={app}\HomeGridBackup.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
InfoBeforeFile=install_hints_before.txt
InfoAfterFile=install_hints_after.txt

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Files]
Source: "installer_payload\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\HomeGrid Backup"; Filename: "{app}\HomeGridBackup.exe"
Name: "{userdesktop}\HomeGrid Backup"; Filename: "{app}\HomeGridBackup.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\HomeGridBackup.exe"; Description: "Launch HomeGrid Backup"; Flags: postinstall nowait skipifsilent
